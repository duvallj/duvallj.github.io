import socketio # pip install python-socketio
import eventlet # pip install eventlet
from multiprocessing import Process, Pipe
import tournament_core # needs to be made already

sio = socketio.Server()
parent_conn, child_conn = Pipe()
last_recv = {'type':'board','bSize':'3','board':'ooo...@@@'}

@sio.on('connect')
def connect(sid, environ):
    print("connect ", sid)

@sio.on('refresh')
def sendReply(sid, data):
    global last_recv
    # we want the last object in the queue
    while parent_conn.poll():
        last_recv = parent_conn.recv()
    sio.emit('reply',data=last_recv)

def main():
    app = socketio.Middleware(sio)

    # the tournament core needs to have a function called run that takes
    # 1 argument, a Connection object, that will send the board updates back
    # when it can.

    # Updates can take 1 of 3 formats:
    #  * Board update, ex {'type':'board', 'bSize':'3', 'board':ooo...@@@'}
    #  * Player names, ex {'type':'names', 'black':'Barry', 'white':'Winston'}
    #  * Wins,         ex {'type':'win', 'winner':'white'}

    game = Process(target=tournament_core.run, args=(child_conn,))
    game.start()
    print('Setup complete')
    eventlet.wsgi.server(eventlet.listen(('',7531)), app)
    # above command runs until server is killed
    game.terminate()
    print('Done')

if __name__=='__main__':
    print('App starting')
    main()
