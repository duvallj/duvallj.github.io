# fake tournament core just to see if other code works

from time import sleep
import random

rchar = lambda:'.o@'[random.randint(0,2)]

def run(pipe_conn):
    while 1:
        size = random.randint(3,10)
        board = ''.join([rchar() for x in range(size*size)])
        pipe_conn.send({'type':'board','bSize':str(size),'board':board})
        sleep(3)
